﻿define("epi-ecf-ui/contentediting/editors/_LanguageRestrictedEditButtonMixin", [
    // dojo
    "dojo/_base/declare",
    "dojo/topic",
    // dijit
    "dijit/form/Button",
    // epi
    "epi/shell/widget/_ModelBindingMixin",
    "epi-cms/contentediting/ContentActionSupport"
], function (
    // dojo
    declare,
    topic,
    // dijit
    Button,
    // epi
    _ModelBindingMixin,
    ContentActionSupport
) {
        return declare([_ModelBindingMixin], {

            changeToView: null,

            buttonLabel: null,

            buttonClass: "epi-chromelessButton epi-visibleLink edit-collection-button",

            iconClass: null,

            isLanguageSpecific: false,

            // contentContext:
            //  accessMask: int
            //  isMasterLanguage: Boolean
            //      Represents if the current content link is shown in the site's master language.
            contentContext: null,

            isLinkButtonCreated: false,

            modelBindingMap: {
                "contentContext": ["contentContext"]
            },

            _setContentContextAttr: function (value) {
                // summary:
                //      Set the current content with accessMask and isMasterLanguage values.
                // description:
                //      Push value to the model to be its data.
                //  tags:
                //      private

                this._set("contentContext", value);

                var isMasterLanguage = value && value.isMasterLanguage;
                if (this.editable !== false && this.buttonLabel && !this.get("isLinkButtonCreated") && (this.isLanguageSpecific || isMasterLanguage)
                    && (value && this._hasAccessRight(value.accessMask))) {
                    this._createButton(value);
                }
            },

            _hasAccessRight: function (accessMask) {
                if (["linksview"].indexOf(this.changeToView) !== -1) {
                    return true;
                }

                return ContentActionSupport.hasAccess(accessMask, ContentActionSupport.accessLevel.Publish);
            },

            _createButton: function (data) {
                var editButton = new Button({
                    label: this.buttonLabel,
                    iconClass: this.iconClass,
                    "class": this.buttonClass
                });

                this.set("isLinkButtonCreated", true);

                this.own(editButton,
                    editButton.on("click", function () {
                        topic.publish("/epi/shell/action/changeview", this.changeToView, {}, data);
                    }.bind(this)));

                this.domNode.appendChild(editButton.domNode);
            }
        });
    });