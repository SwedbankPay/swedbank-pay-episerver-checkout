﻿define("epi-ecf-ui/contentediting/_HasNotificationMixin", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/json",
// dojox
    "dojox/html/entities",
// epi
    "epi/string",
    "epi/shell/widget/dialog/Alert"
], function (
// dojo
    declare,
    json,
// dojox
    htmlEntities,
// epi
    epistring,
    Alert
) {
    // tags:
    //      internal
    return declare(null, {
        _showNotification: function (error, onActionCallback) {
            // summary:
            //      Uses the alert dialog implementation to notify with the error message.
            // tags:
            //      protected

            var alertPopup = new Alert({
                destroyOnHide: true,
                description: epistring.toHTML(htmlEntities.encode(json.fromJson(error.xhr.responseText)))
            });
            if (typeof onActionCallback === "function") {
                alertPopup.onAction = onActionCallback;
            }
            alertPopup.show();
        }
    });
});