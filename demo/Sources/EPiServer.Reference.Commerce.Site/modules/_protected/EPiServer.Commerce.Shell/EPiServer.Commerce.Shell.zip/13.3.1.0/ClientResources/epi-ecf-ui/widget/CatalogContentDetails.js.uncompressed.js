require({cache:{
'url:epi-ecf-ui/widget/templates/CatalogContentDetails.html':"﻿<div class=\"epi-containerLayout\">\r\n    <div data-dojo-type=\"epi/shell/layout/SimpleContainer\" data-dojo-attach-point=\"widgetContainer\"></div>\r\n    <ul>\r\n        <li class=\"epi-formsRow\">\r\n            <label>${resources.visibleto.title}</label>\r\n            <div class=\"epi-formsWidgetWrapper dijitInline\">\r\n                <span data-dojo-attach-point=\"visibleToNode\" class=\"dijitInline\"></span>\r\n                <div data-dojo-type=\"dijit/form/Button\" data-dojo-attach-point=\"manageAccessRightsButton\" data-dojo-attach-event=\"onClick: _onManageAccessRightsClick\" class=\"epi-chromelessButton epi-chromelessLinkButton epi-functionLink\">${resources.manage}</div>\r\n            </div>\r\n        </li>\r\n        <li class=\"epi-formsRow\">\r\n            <label>${resources.existinglanguages}</label>\r\n            <div class=\"epi-formsWidgetWrapper dijitInline epi-formsRow__language--width epi-formsRow__language--floatleft\">\r\n                <span data-dojo-attach-point=\"languagesNode\" class=\"dijitInline\"></span>\r\n            </div>\r\n        </li>\r\n        <li class=\"epi-formsRow\">\r\n            <label>${resources.idandtypename}</label>\r\n            <div class=\"epi-formsWidgetWrapper dijitInline\">\r\n                <span data-dojo-attach-point=\"idNode\" class=\"dijitInline\"></span>, <span data-dojo-attach-point=\"typeNode\" class=\"dijitInline\"></span>\r\n            </div>\r\n        </li>\r\n        <li class=\"epi-formsRow\" data-dojo-attach-point=\"productRow\">\r\n            <label>${resources.product}</label>\r\n            <div class=\"epi-formsWidgetWrapper dijitInline\">\r\n                <span data-dojo-attach-point=\"productNode\" class=\"dijitInline\"></span>\r\n            </div>\r\n        </li>\r\n        <li class=\"epi-formsRow\">\r\n            <label></label>\r\n            <div class=\"epi-formsWidgetWrapper dijitInline\">\r\n                <div data-dojo-attach-point=\"dropdownButton\" data-dojo-type=\"dijit/form/DropDownButton\" class=\"dijit dijitReset dijitInline epi-mediumButton\">\r\n                    <span>${resources.toolsbutton.label}</span>\r\n                    <div data-dojo-type=\"dijit/DropDownMenu\" data-dojo-attach-point=\"additionalActionsMenu\"></div>\r\n                </div>\r\n            </div>\r\n        </li>\r\n    </ul>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/CatalogContentDetails", [
// dojo
        "dojo",
        "dojo/_base/array",
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/_base/url",
        "dojo/_base/window",
        "dojo/aspect",
        "dojo/dom-style",
        "dojo/dom-construct",
        "dojo/string",
        "dojo/topic",
        "dojo/when",

// dijit
        "dijit/form/Button",

// epi shell
        "epi/dependency",
        "epi/shell/layout/SimpleContainer",
        "epi/shell/TypeDescriptorManager",
        "epi/Url",

// epi cms
        "epi-cms/contentediting/ContentDetails",
        "epi-cms/core/PermanentLinkHelper",

// commerce
        "../contentediting/ModelSupport",

// resources
        "epi/i18n!epi/cms/nls/commerce.widget.catalogcontentdetails",
        "dojo/text!./templates/CatalogContentDetails.html"
],
    function (
// dojo
        dojo,
        array,
        declare,
        lang,
        url,
        win,
        aspect,
        domStyle,
        domConstruct,
        dojoString,
        topic,
        when,

// dijit
        Button,

// epi shell
        dependency,
        SimpleContainer,
        TypeDescriptorManager,
        Url,
        ContentDetails,
        PermanentLinkHelper,

// commerce
        ModelSupport,

// resources
        catalogContentDetailsResources,
        template
        ) {

        return declare([ContentDetails], {
            templateString: template,

            _store: null,

            // thumbnailToken: String
            //      Represents the thumbnail token / thumbnail size to be displayed on header as content's asset preview.
            //      This should match the LargeThumbnail property name of EPiServer.Commerce.SpecializedProperties.CommerceImage.
            //      In order to modify the thumnail size, please update EPiServer.Commerce.SpecializedProperties.CommerceImage.LargeThumbnail's ImageDescriptor,
            //      or create a new property, and set this thumbnailToken value to that property name.
            thumbnailToken: "LargeThumbnail",

            // thumbnailNode: DOM node
            //      Represents the thumbnail node, which would be added to the header section, to display content's thumbnail.
            thumbnailNode: null,

            postMixInProperties: function () {
                this.inherited(arguments);
                this.resources = dojo.mixin(this.resources, catalogContentDetailsResources);

                if (!this._store) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this._store = registry.get("epi.commerce.relation");
                }
            },

            buildRendering: function () {
                this.inherited(arguments);

                // Escaping is tricky in the data-dojo-props JSON notation, so setting tooltip here instead.
                this.dropdownButton.set("tooltip", this.resources.toolsbutton.tooltip);
            },

            _setModelAttr: function () {
                this.inherited(arguments);

                if (this.model) {
                    this.own(this.model.watch("dataModel", this._onDataModelChanged.bind(this)));
                }
            },

            _onDataModelChanged: function () {
                // summary:
                //      On data model changed, listen for model's onPropertyEdited even, to update thumbnail image in the header.
                // tags:
                //      private

                if (this.model && this.model.dataModel) {
                    this.own(aspect.after(this.model.dataModel, "onPropertyEdited", function (propertyName, value) {
                        if (propertyName !== "commerceMediaCollection") {
                            return;
                        }

                        this._onMediaCollectionPropertyChanged(value);
                    }.bind(this), true /*receiveArguments setting this as true in order to get corrected propertyName, value arguments (which are original arguments)*/));
                    this._setDefaultAssetGroup();
                    // we need to update thumbnail on first load too
                    this._onMediaCollectionPropertyChanged(this.model.dataModel.contentModel && this.model.dataModel.contentModel["epi-commerceMediaCollection"] || null);

                    var isProductInformationVisible = this._setProductInformationVisibility(this.model.dataModel.contentData);
                    if (isProductInformationVisible) {
                        this._setProductInformation(this.model.dataModel.contentData);
                    }
                }
            },

            _onMediaCollectionPropertyChanged: function (value) {
                // summary:
                //      When commerceMediaCollection property value changed, get the first asset to set as content thumbnail.
                // tags:
                //      private

                if (!value || value.length < 1) {
                    this._renderThumbnail(""); // if content's asset is empty, let's set thumbnail image's source as blank.
                    return;
                }

                var firstAsset = null;
                // looking for the first image in asset list
                array.some(value, function (item) {
                    if (item && TypeDescriptorManager.isBaseTypeIdentifier(item.assetType, "episerver.core.icontentimage")) {
                        if (!firstAsset){
                            firstAsset = item;
                        }
                        if (item.groupName === this.get("defaultGroupName")){
                            firstAsset = item;
                            return item;
                        }
                    }
                }, this);

                if (!firstAsset) {
                    this._renderThumbnail("");
                    return;
                }

                if (firstAsset.previewUrl) {
                    this._renderThumbnail(firstAsset.previewUrl);
                } else {
                    // if firstAsset.previewUrl is not ready, we need to get its preview URL via PermanentLinkHelper
                    when(PermanentLinkHelper.getContent(firstAsset.assetKey), function (content) {
                        if (!content) { // content not found
                            this._renderThumbnail("");
                        } else {
                            this._renderThumbnail(content.previewUrl);
                        }
                    }.bind(this));
                }
            },

            _setDefaultAssetGroup: function() {
                if (!this.model || !this.model.dataModel || !this.model.dataModel.metadata || !this.model.dataModel.metadata.properties){
                    //clear any previous value so we don't keep the default group from any other model.
                    this.set("defaultGroupName", undefined);
                    return;
                }
                var defaultGroupName;
                array.some(this.model.dataModel.metadata.properties, function(property){
                    if (property.name  === "CommerceMediaCollection" && property.settings){
                        defaultGroupName = property.settings.defaultAssetGroupName;
                        return true;
                    }
                });
                this.set("defaultGroupName", defaultGroupName);
            },

            addChild: function (w) {
                this.widgetContainer.addChild(w);
            },

            _renderThumbnail: function (imageUrl) {
                // summary:
                //      Injects the thumbnail image to the header section (if it was not added), and update its image URL.
                // tags:
                //      protected

                var parentNode = this.domNode.parentNode;
                if (!parentNode) {
                    return;
                }
                
                var imageSource = "";
                if (imageUrl) {
                    var url = new Url(imageUrl);
                    url.path += "/" + this.thumbnailToken;
                    lang.mixin(url.query, { time: new Date().getTime() }); // append time parameter to make sure image will be refresh all the time, to avoid cache issue.
                    imageSource = url.toString();
                }

                if (!this.thumbnailNode) {
                    this.thumbnailNode = domConstruct.create("img", {
                        src: imageSource,
                        className: "epi-heading-thumbnail"
                    });
                    domConstruct.place(this.thumbnailNode, parentNode, "first");
                } else {
                    this.thumbnailNode.src = imageSource;
                }

                domStyle.set(this.thumbnailNode, "display", !!imageSource ? "block" : "none");
            },

            _setExistingLanguagesAttr: function (languages) {
                this.languagesNode.innerHTML = "";

                // Create text or link elements base on language information.
                array.forEach(languages, function (item, idx) {
                    var elm, isLast = idx === languages.length - 1;
                    if (this.model.dataModel.currentContentLanguage === item.text) {
                        elm = domConstruct.create("span", {
                            innerHTML: item.urlSegment
                        });
                    } else {
                        var url = new dojo._Url(window.top.location.href);
                        elm = domConstruct.create("a", {
                            innerHTML: item.urlSegment,
                            href: [url.scheme, "://", url.authority, url.path, "?language=", item.text, "#context=epi.cms.contentdata:///", item.contentLink].join(""),
                            "class": "epi-visibleLink"
                        });
                    }
                    domConstruct.place(elm, this.languagesNode);

                    if (!isLast) {                        
                        domConstruct.create("span", { innerHTML: ", " }, this.languagesNode);
                    }
                }, this);
            },

            _setProductInformation: function (contentData) {
                if (!contentData) {
                    return;
                }

                var query = {
                    referenceId: contentData.contentLink,
                    relationTypes: [ModelSupport.relationType.productVariation],
                    requestMode: ModelSupport.relationRequestMode.byTarget
                };

                when(this._store.query(query)).then(function (products) {
                    if (!products || products.length === 0) {
                        this.productNode.innerHTML = catalogContentDetailsResources.none;
                    } else if (products.length === 1) {
                        this._createNavigationButton(products[0].name, products[0].source);
                    } else {
                        this.productNode.innerHTML = dojoString.substitute(
                            catalogContentDetailsResources.products,
                            { numberOfProducts: products.length });
                    }
                }.bind(this));
            },

            _createNavigationButton: function (label, contentLink) {
                var linkButton = new Button({
                    label: label,
                    "class": "epi-chromelessButton epi-chromeless--text-only epi-visibleLink",
                    onClick: function () {
                        topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + contentLink }, { sender: this });
                    }.bind(this)
                }, this.productNode);

                this.own(linkButton);
            },

            _setProductInformationVisibility: function (contentData) {
                if (!contentData) {
                    return;
                }

                if (TypeDescriptorManager.isBaseTypeIdentifier(contentData.typeIdentifier, ModelSupport.contentTypeIdentifier.variationContent)) {
                    domStyle.set(this.productRow, "display", "block");
                    return true;
                } else {
                    domStyle.set(this.productRow, "display", "none");
                    return false;
                }
            }
        });
    });
