﻿define("epi-ecf-ui/contentediting/editors/_GroupDefinitionEditorMixin", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-construct",
    
    // dijit
    "dijit/form/Button",
    
    // epi
    "epi/shell/widget/dialog/Dialog",
    
    // epi-ecf-ui
    "./RelationGroupDefinitionEditor",

    // resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.relationgroupeditor",
    "epi/i18n!epi/nls/episerver.shared"

],
function (
    // dojo
    declare,
    domConstruct,
    
    // dijit
    Button,

    // epi
    Dialog,
    
    // epi-ecf-ui
    RelationGroupDefinitionEditor,

    // resources
    groupEditorResources,
    sharedResources
) {

    return declare([], {

        buildRendering: function () {
            this.inherited(arguments);
            var button = new Button({
                "class": "epi-trailingButton",
                label: groupEditorResources.editbuttontext,
                title: groupEditorResources.editbuttontext
            });

            domConstruct.place(button.domNode, this.collectionList, "before");

            this.own(button.on("click", function () {
                var groupDefinitionEditor = new RelationGroupDefinitionEditor();
                var dialog = new Dialog({
                    defaultActionsVisible: false,
                    content: groupDefinitionEditor,
                    title: groupEditorResources.title,
                    closeIconVisible: false,
                    getActions: function(){
                        var done = {
                            name: "done",
                            label: sharedResources.action.done,
                            title: null,
                            settings: { type: "submit", "class": "Salt" }
                        };
                        return [done];
                    }
                });
                dialog.show();
            }));
        }
    });
});
